import pandas as pd
import numpy as np

# Generate sample data
n = 5000
data = {
    "transaction_amount": np.random.uniform(10, 5000, n),
    "distance_from_home": np.random.uniform(1, 200, n),
    "device_change": np.random.randint(0, 2, n),
    "is_fraud": np.random.randint(0, 2, n),
}

df = pd.DataFrame(data)

df.to_csv("../data/sample_transactions.csv", index=False)
print("Sample data generated!")
