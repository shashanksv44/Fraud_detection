import joblib
import numpy as np

model = joblib.load("../models/fraud_model.pkl")

def predict_fraud(amount, distance, device_change):
    features = np.array([[amount, distance, device_change]])
    prediction = model.predict(features)[0]
    return int(prediction)
