from flask import Flask, request, jsonify
from ml_utils import predict_fraud
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # 🔥 FIXES CONNECTION ISSUE

@app.route("/")
def home():
    return "Fraud Detection API Running!"

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()

    transaction_amount = data.get("transaction_amount")
    distance_from_home = data.get("distance_from_home")
    device_change = data.get("device_change")

    result = predict_fraud(
        transaction_amount,
        distance_from_home,
        device_change
    )

    return jsonify({"fraud_prediction": result})

if __name__ == "__main__":
    app.run(debug=True)
